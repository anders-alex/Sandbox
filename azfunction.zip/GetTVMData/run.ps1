﻿# Input bindings are passed in via param block.
param($Timer)

$lawResourceId = $env:LAW_RESOURCE_ID
$tenantId = $env:TENANT_ID
$appId = $env:APP_ID
$appSecret = $env:APP_SECRET
$dcrImmutableId = $env:DCR_IMMUTABLE_ID
$dceURI = $env:DCE_URI
$snapshotTime = Get-Date -Format s
$batchSize = $env:BATCH_SIZE

function Get-AADToken {
    param ($resource, $scope, $oAuthUri, $clientId, $clientSecret)
    if ($null -ne $resource) {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/token"
        $authBody = "client_id=$clientId&resource=$resource&client_secret=$clientSecret&grant_type=client_credentials"
    }
    else {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
        $authBody = "client_id=$clientId&scope=$scope&client_secret=$clientSecret&grant_type=client_credentials"
    }
    $authHeaders = @{"Content-Type" = "application/x-www-form-urlencoded" }
    $authResponse = Invoke-RestMethod -Method Post -Uri $oAuthUri -Body $authBody -Headers $authHeaders -ErrorAction Stop
    return $authResponse.access_token
}

function Get-RequestHeaders {
    param ($token)
    return @{"Authorization" = "Bearer $token"; "Content-Type" = "application/json" }
}

$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $appId, (ConvertTo-SecureString $appSecret -AsPlainText -Force)
Connect-AzAccount -ServicePrincipal -TenantId $tenantId -Credential $credential -Subscription $lawResourceId.Split('/')[2]

$lawId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawResourceId.Split('/')[4] -Name $lawResourceId.Split('/')[8]).CustomerId

$defenderToken = Get-AADToken -resource 'https://api.securitycenter.microsoft.com' -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
$azMonToken = Get-AADToken -scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"

#Ingest Vulnerabilities by Device
$defenderUri = "https://api.securitycenter.windows.com/api/machines/SoftwareVulnerabilitiesByMachine"
$table = 'TVMVulnerabilitiesByDevice_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"

do {
    $response = Invoke-WebRequest -Method Get -Uri $defenderUri -Headers (Get-RequestHeaders -token $defenderToken) -ErrorAction Stop
    $body = New-Object System.Collections.ArrayList
    foreach ($item in ($response.Content | ConvertFrom-Json).value) {
        $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $snapshotTime
        $item | Add-Member -MemberType AliasProperty -Name vulnId -Value Id
        $body.Add($item) | Out-Null
    }
    $skip = 0
    do {
        Invoke-RestMethod -Uri $azMonUri -Method "Post" -Body ($body | Select-Object -ExcludeProperty Id -Skip $skip | Select-Object -First $batchSize | ConvertTo-Json) -Headers (Get-RequestHeaders -token $azMonToken)
        $skip += $batchSize
    } until ($skip -ge $body.Count)
    
    $defenderUri = ($response.Content | ConvertFrom-Json).'@odata.nextLink'
} until ($null -eq $defenderUri)

#Ingest Recommendations
$defenderUri = 'https://api.securitycenter.windows.com/api/recommendations'
$table = 'TVMRecommendations_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"

do {
    $response = Invoke-WebRequest -Method Get -Uri $defenderUri -Headers (Get-RequestHeaders -token $defenderToken) -ErrorAction Stop
    $body = New-Object System.Collections.ArrayList
    foreach ($item in ($response.Content | ConvertFrom-Json).value) {
        $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $snapshotTime
        $item | Add-Member -MemberType AliasProperty -Name recId -Value Id
        $body.Add($item) | Out-Null
    }
    $skip = 0
    do {
        Invoke-RestMethod -Uri $azMonUri -Method "Post" -Body ($body | Select-Object -ExcludeProperty Id -Skip $skip | Select-Object -First $batchSize | ConvertTo-Json) -Headers (Get-RequestHeaders -token $azMonToken)
        $skip += $batchSize
    } until ($skip -ge $body.Count)
    
    $defenderUri = ($response.Content | ConvertFrom-Json).'@odata.nextLink'
} until ($null -eq $defenderUri)

#Ingest CVE KB
$lawQuery = 'TVMCVEKB_CL | order by todatetime(updatedOn) desc | take 1 | project updatedOn'
$tvmKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'TVMCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$tvmKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$tvmKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'TVMCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $tvmKbLastUpdate.Results.updatedOn -Or $tvmKBOldestRecord.Results.OldestRecord -ge ($tvmKbRetention - 5)) {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities'
}
else {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities?$filter=updatedOn+gt+' + $tvmKbLastUpdate.Results.updatedOn
}

$table = 'TVMCVEKB_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"

do {
    $response = Invoke-WebRequest -Method Get -Uri $defenderUri -Headers (Get-RequestHeaders -token $defenderToken) -ErrorAction Stop
    if (($response.Content | ConvertFrom-Json).value.count -eq 0) {break}
    $body = New-Object System.Collections.ArrayList
    foreach ($item in ($response.Content | ConvertFrom-Json).value) {
        $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $snapshotTime
        $item | Add-Member -MemberType AliasProperty -Name cveId -Value Id
        $body.Add($item) | Out-Null
    }
    $skip = 0
    do {
        Invoke-RestMethod -Uri $azMonUri -Method "Post" -Body ($body | Select-Object -ExcludeProperty Id -Skip $skip | Select-Object -First $batchSize | ConvertTo-Json) -Headers (Get-RequestHeaders -token $azMonToken)
        $skip += $batchSize
    } until ($skip -ge $body.Count)
    
    $defenderUri = ($response.Content | ConvertFrom-Json).'@odata.nextLink'
} until ($null -eq $defenderUri)